# MOVIE WORLD — free-hosting edition

Bilingual English/Urdu movie catalogue designed for **Cloudflare Pages + D1** on the free tiers. It includes public browsing, search, categories, an admin login, adding Google Drive links, and deleting catalogue entries.

## Important free-plan limits
- This edition does **not** store video files on the website host. Upload a video to your own Google Drive account from your phone, set access to “Anyone with the link” if you intend public viewing, then add its share link in the admin panel.
- Google Drive may show sign-in prompts, limit previews/downloads, or enforce quotas. It is not a guaranteed public streaming CDN.
- The website uses Cloudflare D1 for movie details. Free-plan limits and policies can change; check Cloudflare's current limits before launch.
- `movieworld.pages.dev` is an example free address after deployment; the exact assigned address depends on the Cloudflare project name. A custom `.pk` domain is optional and costs extra.

## Deploy for free

1. Create a Cloudflare account and a GitHub account.
2. Create a new GitHub repository and upload the contents of this folder (the `public`, `functions`, `schema.sql`, and config files).
3. In Cloudflare Dashboard, open **Workers & Pages → Create → Pages → Connect to Git** and select the repository.
4. Use these build settings:
   - Framework preset: **None**
   - Build command: leave blank
   - Build output directory: `public`
5. In the Pages project, open **Settings → Functions → D1 database bindings** and add a binding named `DB` connected to a new D1 database.
6. In the D1 database console, run the SQL from `schema.sql`.
7. In Pages project **Settings → Variables and Secrets**, add:
   - `ADMIN_USERNAME` = `admin` (or your preferred username)
   - `ADMIN_PASSWORD` = a long, unique password (mark it as a secret)
8. Redeploy the project. Open the assigned `*.pages.dev` address and `/admin.html`.

## Local preview

This edition uses Cloudflare Pages Functions and D1, so it is not run with `npm start`. Use the Cloudflare Pages local development workflow (`wrangler pages dev public --d1 DB=<database-name>`), after installing Wrangler and creating a local D1 database. Add the same environment variables locally.

## Security and content

- Use a unique strong admin password and HTTPS. The admin password is kept in the browser tab's session storage and sent only to same-origin API endpoints over HTTPS; log out on shared devices.
- Add only movies you own or are legally authorized to distribute. Do not publish copyrighted films without permission.
- This is a small catalogue MVP, not a high-traffic streaming service. Review current Cloudflare and Google Drive limits before relying on it publicly.
