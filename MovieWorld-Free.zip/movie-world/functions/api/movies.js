export async function onRequestGet({ env }) {
  const { results = [] } = await env.DB.prepare(
    "SELECT id,title,titleUr,description,descriptionUr,category,year,poster,driveId FROM movies ORDER BY createdAt DESC"
  ).all();
  return Response.json(results.map(m => ({
    ...m,
    type: "drive",
    streamUrl: `https://drive.google.com/file/d/${m.driveId}/preview`,
    downloadUrl: `https://drive.google.com/uc?export=download&id=${m.driveId}`
  })));
}
