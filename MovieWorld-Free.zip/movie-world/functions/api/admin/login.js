export async function onRequestPost({ request, env }) {
  if (!env.ADMIN_PASSWORD) return Response.json({ error: "Admin password is not configured." }, { status: 503 });
  let body;
  try { body = await request.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
  if ((body.username || "") !== (env.ADMIN_USERNAME || "admin") || body.password !== env.ADMIN_PASSWORD) {
    return Response.json({ error: "Incorrect username or password." }, { status: 401 });
  }
  return Response.json({ ok: true });
}
