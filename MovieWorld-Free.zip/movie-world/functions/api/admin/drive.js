function getDriveId(input) {
  try {
    const u = new URL(input);
    if (!["drive.google.com", "docs.google.com"].includes(u.hostname)) return null;
    const match = u.pathname.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    return u.searchParams.get("id") || (match && match[1]) || null;
  } catch { return null; }
}
function authorized(request, env) {
  return !!env.ADMIN_PASSWORD && request.headers.get("x-admin-password") === env.ADMIN_PASSWORD;
}
export async function onRequestPost({ request, env }) {
  if (!authorized(request, env)) return Response.json({ error: "Admin login required." }, { status: 401 });
  let b;
  try { b = await request.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
  const driveId = getDriveId(b.driveUrl || "");
  if (!driveId) return Response.json({ error: "Enter a valid Google Drive file link." }, { status: 400 });
  const movie = {
    id: crypto.randomUUID(), title: String(b.title || "Untitled").slice(0,120),
    titleUr: String(b.titleUr || "").slice(0,120), description: String(b.description || "").slice(0,1000),
    descriptionUr: String(b.descriptionUr || "").slice(0,1000), category: String(b.category || "Other").slice(0,50),
    year: String(b.year || "").slice(0,4), poster: String(b.poster || "").startsWith("https://") ? String(b.poster).slice(0,500) : "",
    driveId, createdAt: new Date().toISOString()
  };
  await env.DB.prepare(`INSERT INTO movies (id,title,titleUr,description,descriptionUr,category,year,poster,driveId,createdAt)
    VALUES (?,?,?,?,?,?,?,?,?,?)`).bind(movie.id,movie.title,movie.titleUr,movie.description,movie.descriptionUr,movie.category,movie.year,movie.poster,movie.driveId,movie.createdAt).run();
  return Response.json({ ok: true, movie });
}
