export async function onRequestDelete({ request, env, params }) {
  if (!env.ADMIN_PASSWORD || request.headers.get("x-admin-password") !== env.ADMIN_PASSWORD) {
    return Response.json({ error: "Admin login required." }, { status: 401 });
  }
  const result = await env.DB.prepare("DELETE FROM movies WHERE id = ?").bind(params.id).run();
  if (!result.meta.changes) return Response.json({ error: "Movie not found." }, { status: 404 });
  return Response.json({ ok: true });
}
