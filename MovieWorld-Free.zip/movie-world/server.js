const express = require("express");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads");
const DB_FILE = path.join(DATA_DIR, "movies.json");
for (const dir of [DATA_DIR, UPLOAD_DIR]) fs.mkdirSync(dir, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]");

const readMovies = () => JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
const saveMovies = (movies) => fs.writeFileSync(DB_FILE, JSON.stringify(movies, null, 2));
const adminUser = process.env.ADMIN_USERNAME || "admin";
const adminPass = process.env.ADMIN_PASSWORD;
if (!adminPass) console.warn("WARNING: Set ADMIN_PASSWORD in your environment before exposing this site publicly.");

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use("/api/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }));
app.use(express.static(path.join(ROOT, "public")));

const requireAdmin = (req, res, next) => req.session && req.session.isAdmin ? next() : res.status(401).json({ error: "Admin login required" });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, "");
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  }
});
const maxBytes = Math.max(1, Number(process.env.MAX_UPLOAD_GB || 2)) * 1024 * 1024 * 1024;
const upload = multer({
  storage, limits: { fileSize: maxBytes },
  fileFilter: (_req, file, cb) => file.mimetype.startsWith("video/") ? cb(null, true) : cb(new Error("Please upload a video file."))
});

function getDriveId(input) {
  try {
    const u = new URL(input);
    if (!["drive.google.com", "docs.google.com"].includes(u.hostname)) return null;
    const byPath = u.pathname.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    return u.searchParams.get("id") || (byPath && byPath[1]) || null;
  } catch { return null; }
}

app.get("/api/movies", (_req, res) => {
  res.json(readMovies().map(({ id, title, titleUr, description, descriptionUr, category, year, poster, source, driveId, filename }) => ({
    id, title, titleUr, description, descriptionUr, category, year, poster,
    type: source, streamUrl: source === "upload" ? `/stream/${id}` : `https://drive.google.com/file/d/${driveId}/preview`,
    downloadUrl: source === "upload" ? `/download/${id}` : `https://drive.google.com/uc?export=download&id=${driveId}`
  })));
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!adminPass || username !== adminUser || password !== adminPass) return res.status(401).json({ error: "Incorrect username or password" });
  req.session.isAdmin = true;
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/admin/status", (req, res) => res.json({ loggedIn: !!(req.session && req.session.isAdmin) }));

app.post("/api/admin/upload", requireAdmin, (req, res, next) => {
  upload.single("video")(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    next();
  });
}, (req, res) => {
  if (!req.file) return res.status(400).json({ error: "Choose a video file." });
  const movie = makeMovie(req.body, { source: "upload", filename: req.file.filename });
  const movies = readMovies(); movies.unshift(movie); saveMovies(movies);
  res.json({ ok: true, movie });
});

app.post("/api/admin/drive", requireAdmin, (req, res) => {
  const driveId = getDriveId((req.body || {}).driveUrl || "");
  if (!driveId) return res.status(400).json({ error: "Enter a valid Google Drive file link." });
  const movie = makeMovie(req.body, { source: "drive", driveId });
  const movies = readMovies(); movies.unshift(movie); saveMovies(movies);
  res.json({ ok: true, movie });
});

function makeMovie(body, sourceInfo) {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    title: String(body.title || "Untitled").slice(0, 120),
    titleUr: String(body.titleUr || "").slice(0, 120),
    description: String(body.description || "").slice(0, 1000),
    descriptionUr: String(body.descriptionUr || "").slice(0, 1000),
    category: String(body.category || "Other").slice(0, 50),
    year: String(body.year || "").slice(0, 4),
    poster: String(body.poster || "").startsWith("https://") ? String(body.poster).slice(0, 500) : "",
    ...sourceInfo, createdAt: new Date().toISOString()
  };
}

app.delete("/api/admin/movies/:id", requireAdmin, (req, res) => {
  const movies = readMovies();
  const movie = movies.find(m => m.id === req.params.id);
  if (!movie) return res.status(404).json({ error: "Movie not found." });
  if (movie.source === "upload") {
    const file = path.join(UPLOAD_DIR, path.basename(movie.filename));
    if (fs.existsSync(file)) fs.unlinkSync(file);
  }
  saveMovies(movies.filter(m => m.id !== req.params.id));
  res.json({ ok: true });
});

app.get("/stream/:id", (req, res) => {
  const movie = readMovies().find(m => m.id === req.params.id && m.source === "upload");
  if (!movie) return res.sendStatus(404);
  const file = path.join(UPLOAD_DIR, path.basename(movie.filename));
  if (!fs.existsSync(file)) return res.sendStatus(404);
  res.type(path.extname(file));
  res.sendFile(file);
});
app.get("/download/:id", (req, res) => {
  const movie = readMovies().find(m => m.id === req.params.id && m.source === "upload");
  if (!movie) return res.sendStatus(404);
  const file = path.join(UPLOAD_DIR, path.basename(movie.filename));
  if (!fs.existsSync(file)) return res.sendStatus(404);
  res.download(file, `${movie.title.replace(/[^a-z0-9-_ ]/gi, "").trim() || "movie"}${path.extname(file)}`);
});

app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(400).json({ error: err.message || "Request failed." });
});
app.listen(PORT, () => console.log(`Movie World is running at http://localhost:${PORT}`));
