let movies = [], lang = "en";
const $ = s => document.querySelector(s);
const esc = s => String(s || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function applyLang(){document.documentElement.lang=lang;document.documentElement.dir="ltr";document.querySelectorAll("[data-en]").forEach(el=>el.textContent=lang==="ur"?el.dataset.ur:el.dataset.en);$("#langBtn").textContent=lang==="en"?"اردو":"English";render();}
$("#langBtn").addEventListener("click",()=>{lang=lang==="en"?"ur":"en";applyLang();});
function render(){
 const q=$("#search").value.toLowerCase(), cat=$("#category").value;
 const filtered=movies.filter(m=>(!cat||m.category===cat)&&(`${m.title} ${m.titleUr} ${m.description} ${m.category}`).toLowerCase().includes(q));
 $("#count").textContent=`${filtered.length} movies`;
 $("#movies").innerHTML=filtered.length?filtered.map(m=>`<article class="movie-card">${m.poster?`<img class="poster" src="${esc(m.poster)}" alt="">`:`<div class="poster-placeholder">▶</div>`}<div class="movie-info"><h3>${esc(lang==="ur"&&m.titleUr?m.titleUr:m.title)}</h3><p>${esc(m.year)}${m.year?" · ":""}${esc(m.category)}</p><div class="actions"><a href="${esc(m.streamUrl)}" target="_blank" rel="noopener">${lang==="ur"?"دیکھیں":"Watch"}</a><a href="${esc(m.downloadUrl)}" target="_blank" rel="noopener">${lang==="ur"?"ڈاؤن لوڈ":"Download"}</a></div></div></article>`).join(""):`<p class="muted">${lang==="ur"?"ابھی کوئی مووی شامل نہیں کی گئی۔":"No movies added yet."}</p>`;
}
async function init(){try{movies=await fetch("/api/movies").then(r=>r.json());const cats=[...new Set(movies.map(m=>m.category).filter(Boolean))];$("#category").innerHTML='<option value="">All categories</option>'+cats.map(c=>`<option>${esc(c)}</option>`).join("");render();}catch{$("#movies").textContent="Could not load movies.";}}
$("#search").addEventListener("input",render);$("#category").addEventListener("change",render);$("#year").textContent=new Date().getFullYear();init();