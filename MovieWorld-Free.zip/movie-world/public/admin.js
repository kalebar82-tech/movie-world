const $=s=>document.querySelector(s);
const passwordKey="mw_admin_password";
const savedPassword=()=>sessionStorage.getItem(passwordKey)||"";
async function api(url,opts={}){const headers=new Headers(opts.headers||{});if(savedPassword())headers.set("x-admin-password",savedPassword());const r=await fetch(url,{...opts,headers});const data=await r.json().catch(()=>({}));if(!r.ok)throw Error(data.error||"Request failed");return data;}
function msg(t){$("#adminMsg").textContent=t;}
async function refresh(){const ms=await api("/api/movies");$("#manageList").innerHTML=ms.length?ms.map(m=>`<div class="manage-row"><span>${String(m.title).replace(/[&<>\"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))} (${m.category||"Other"})</span><button class="outline" data-id="${m.id}">Delete</button></div>`).join("") : "<p class='hint'>No movies yet.</p>";$("#manageList").querySelectorAll("button").forEach(b=>b.onclick=async()=>{if(confirm("Delete this movie?")){try{await api("/api/admin/movies/"+encodeURIComponent(b.dataset.id),{method:"DELETE"});await refresh();}catch(e){msg(e.message);}}});}
function showDashboard(on){$("#loginBox").hidden=on;$("#dashboard").hidden=!on;}
$("#loginForm").onsubmit=async e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));try{await api("/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)});sessionStorage.setItem(passwordKey,d.password);showDashboard(true);$("#loginMsg").textContent="";await refresh();}catch(x){sessionStorage.removeItem(passwordKey);$("#loginMsg").textContent=x.message;}};
$("#driveForm").onsubmit=async e=>{e.preventDefault();msg("Adding…");try{await api("/api/admin/drive",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target))),headers:{"Content-Type":"application/json"}});e.target.reset();msg("Movie added.");await refresh();}catch(x){msg(x.message);}};
$("#logout").onclick=()=>{sessionStorage.removeItem(passwordKey);showDashboard(false);};
async function init(){if(savedPassword()){try{await refresh();showDashboard(true);}catch{sessionStorage.removeItem(passwordKey);showDashboard(false);}}else showDashboard(false);}
init();
