CREATE TABLE IF NOT EXISTS movies (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  titleUr TEXT DEFAULT '',
  description TEXT DEFAULT '',
  descriptionUr TEXT DEFAULT '',
  category TEXT DEFAULT 'Other',
  year TEXT DEFAULT '',
  poster TEXT DEFAULT '',
  driveId TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_movies_createdAt ON movies(createdAt);
